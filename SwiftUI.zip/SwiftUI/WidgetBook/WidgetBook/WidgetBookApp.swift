//
//  WidgetBookApp.swift
//  WidgetBook
//
//  Created by Mihir vyas on 27/06/23.
//

import SwiftUI

@main
struct WidgetBookApp: App {
    var body: some Scene {
        WindowGroup {
            EmojibookListView()
        }
    }
}
