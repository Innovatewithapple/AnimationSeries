//
//  ContentView.swift
//  WidgetBook
//
//  Created by Mihir vyas on 27/06/23.
//

import SwiftUI


/// TableList to show emojis
struct EmojibookListView: View {
    
    let emojiData:[EmojiDetails] = EmojiProvider.all()
    @State private var showingDetail: Bool = false
    
    var body: some View {
       NavigationView {
         List {
           ForEach(emojiData, content: { emojiDetails in
             Button(action: {
               showingDetail.toggle()
             }, label: {
               EmojiItemView(emoji: emojiDetails.emoji, emojiName: emojiDetails.name)
             })
             .sheet(isPresented: $showingDetail) {
               EmojiDetailsView(emojiDetails: emojiDetails)
             }
           })
         }
         .foregroundColor(.red)
         .listStyle(InsetGroupedListStyle())
         .navigationBarTitle("Emojibook")
       }
     }
   }


/// Custom Struct to display emoji with name
struct EmojiItemView: View {
    let emoji: String
    let emojiName: String
    
    var body: some View {
        Text("\(emoji) \(emojiName)")
          .font(.largeTitle)
          .padding([.top, .bottom])
      }
}


/// Custom Detail view to show emoji description on Sheet
struct EmojiDetailsView: View {
    let emojiDetails: EmojiDetails
   
    
    var body: some View {
        ZStack{
            //Background Color
            Color(UIColor.systemIndigo).edgesIgnoringSafeArea(.all)
            
            //Emoji Data
            VStack {
                VStack(alignment: .leading) {
                    HStack {
                        Text("\(emojiDetails.emoji) \(emojiDetails.name)")
                                      .font(.largeTitle)
                                      .bold()
                    }
                    .padding()
                    Text(emojiDetails.description)
                                .padding([.leading, .trailing, .bottom])
                                .font(.title)
                }
            }
            .foregroundColor(.white)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        EmojibookListView()
    }
}
