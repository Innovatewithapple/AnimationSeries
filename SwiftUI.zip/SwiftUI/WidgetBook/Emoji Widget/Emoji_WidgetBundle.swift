//
//  Emoji_WidgetBundle.swift
//  Emoji Widget
//
//  Created by Mihir vyas on 27/06/23.
//

import WidgetKit
import SwiftUI

@main
struct Emoji_WidgetBundle: WidgetBundle {
    var body: some Widget {
        Emoji_Widget()
        Emoji_WidgetLiveActivity()
    }
}
