//
//  UILabel+Extensions.swift
//  AnimationSeries
//
//  Created by Mihir vyas on 27/06/23.
//

import Foundation
import UIKit

extension UILabel {
    func setSizeFont (sizeFont: CGFloat) {
        self.font =  UIFont(name: self.font.fontName, size: sizeFont)!
        self.sizeToFit()
    }
}
