//
//  UIView+Extensions.swift
//  AnimationSeries
//
//  Created by Mihir vyas on 29/06/23.
//

import Foundation
import UIKit

class ClockFace: UIView {

    var calendar: NSCalendar!
    var time: Date!
    private var figureCenter: CGPoint = .zero
    private var faceRadius: CGFloat = 0
    private var seconds: Int = 0
    private var minutes: Int = 0
    private var hours: Int = 0
    private let angleOffset: CGFloat = -.pi / 2 // an offset to make 0 at "12:00" instead of "3:00"

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        figureCenter = CGPoint(x: bounds.midX, y: bounds.midY)
        faceRadius = frame.size.width / 2.0
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        // Initialization code
        figureCenter = CGPoint(x: bounds.midX, y: bounds.midY)
        faceRadius = frame.size.width / 2.0
    }

    func secondsHandPosition() -> CGPoint {
        let radiansPerSecond = (CGFloat.pi * 2) / 60
        let secondsAsRadians: CGFloat = angleOffset + (CGFloat(seconds) * radiansPerSecond )
        let handRadius: CGFloat = faceRadius / 1.1
        return CGPoint(x: CGFloat(handRadius * cos(secondsAsRadians) + figureCenter.x), y: CGFloat(handRadius * sin(secondsAsRadians) + figureCenter.y))
    }

    func minutesHandPosition() -> CGPoint {
        let radiansPerMinute = (CGFloat.pi * 2) / 60
        let minutesAsRadians: CGFloat = angleOffset + (CGFloat(minutes) * radiansPerMinute)
        let handRadius: CGFloat = faceRadius / 1.25
        return CGPoint(x: CGFloat(handRadius * cos(minutesAsRadians) + figureCenter.x), y: CGFloat(handRadius * sin(minutesAsRadians) + figureCenter.y))
    }

    func hoursHandPosition() -> CGPoint {
        let radiansPerHour = (CGFloat.pi * 2) / 12
        let hoursAsRadians: CGFloat = angleOffset + (CGFloat(hours) * radiansPerHour)
        let handRadius: CGFloat = faceRadius / 1.8
        return CGPoint(x: CGFloat(handRadius * cos(hoursAsRadians) + figureCenter.x), y: CGFloat(handRadius * sin(hoursAsRadians) + figureCenter.y))
    }

    override func draw(_ rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()!
        context.setFillColor(UIColor.clear.cgColor)
        context.fill(rect)

        for count in 0...60 {
            let tickRadius = faceRadius / ((count % 5 == 0) ? 1.20 : 1.15)
            let lineWidth = (count % 5) == 0 ? 3 : 2
            let tickAngle = CGFloat(count) * ((CGFloat.pi * 2) / 60)
            context.beginPath()
            context.move(to: CGPoint(x: CGFloat(faceRadius * cos(tickAngle) + figureCenter.x), y: CGFloat(faceRadius * sin(tickAngle) + figureCenter.y)))
            context.addLine(to: CGPoint(x: CGFloat(tickRadius * cos(tickAngle) + figureCenter.x), y: CGFloat(tickRadius * sin(tickAngle) + figureCenter.y)))

            context.setStrokeColor(UIColor.clear.cgColor)
            context.setLineWidth(CGFloat(lineWidth))
            context.strokePath()
        }

        let lineWidth: CGFloat = 5.0
        let face = rect.insetBy(dx: lineWidth / 2, dy: lineWidth / 2)
        context.setLineWidth(lineWidth)
        context.addEllipse(in: face)
        context.strokePath()

        let secondsHandPosition = self.secondsHandPosition()

        context.beginPath()
        context.move(to: figureCenter)
        context.addLine(to: secondsHandPosition)
        context.setLineWidth(3)
        context.setStrokeColor(UIColor.red.cgColor)
        context.strokePath()

//        let minutesHandPosition = self.minutesHandPosition()
//
//        context.beginPath()
//        context.move(to: figureCenter)
//        context.addLine(to: minutesHandPosition)
//        context.setLineWidth(3)
//        context.setStrokeColor(UIColor.clear.cgColor)
//        context.strokePath()
//
//        let hoursHandPosition = self.hoursHandPosition()
//
//        context.beginPath()
//        context.move(to: figureCenter)
//        context.addLine(to: hoursHandPosition)
//        context.setLineWidth(5)
//        context.setStrokeColor(UIColor.clear.cgColor)
//        context.strokePath()

        let center = CGRect(x: figureCenter.x - 5.0, y: figureCenter.y - 5.0, width: 10.0, height: 10.0)
        context.addEllipse(in: center)
        context.setFillColor(UIColor.black.cgColor)
        context.fillPath()
        context.strokePath()
    }

    func setTime(_ time: Int) {

        //self.time = time
        var weekdayComponents: DateComponents!

        if calendar == nil {
            calendar = NSCalendar(identifier: NSCalendar.Identifier.gregorian)
        }

//        if let time = time {
//            weekdayComponents = calendar.components([.day, .weekday, .hour, .minute, .second], from: time)
//        }

//        if weekdayComponents != nil {
//            hours = weekdayComponents.hour!
//            minutes = weekdayComponents.minute!
//            seconds = 1//weekdayComponents.second!
//
//            hours = (hours + (12 - 1)) % 12 + 1;
//        }
        seconds = time
        self.setNeedsDisplay()
    }
}


extension UIView {
    func rotate360Degrees(duration: CFTimeInterval = 3) {
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        rotateAnimation.toValue = CGFloat(M_PI * 2)
        rotateAnimation.isRemovedOnCompletion = false
        rotateAnimation.duration = duration
        rotateAnimation.repeatCount=Float.infinity
        self.layer.add(rotateAnimation, forKey: nil)
    }
}

extension UIView {
        func flash(numberOfFlashes: Float) {
           let flash = CABasicAnimation(keyPath: "opacity")
           flash.duration = 0.2
           flash.fromValue = 1
           flash.toValue = 0.1
           flash.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
           flash.autoreverses = true
           flash.repeatCount = numberOfFlashes
           layer.add(flash, forKey: nil)
       }
 }
