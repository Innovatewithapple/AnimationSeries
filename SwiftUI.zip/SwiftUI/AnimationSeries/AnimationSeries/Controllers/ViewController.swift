//
//  ViewController.swift
//  AnimationSeries
//
//  Created by Mihir vyas on 27/06/23.
//

import UIKit

class ViewController: UIViewController {
    
    ///Main View
    var MainView:UIView!
    
    ///TableView
    var tableV:UITableView!
    
    /// Custom Labels
    var welcomeLableFirst: UILabel!
    var welcomeLableSecond: UILabel!
    var welcomeLableThird: UILabel!
    
    /// Custom Buttons
    var settingButton:UIButton!
    
    /// Custom Views
    var hexaView:UIView!
    var bottomButtonView: UIView!
    var bottomButtonViewLabel: UILabel!
    var bottomButtonViewInnerButton:UIButton!
    
    /// Animate Position
    var FirstLabelPosition = CGFloat()
    var SecondLabelPosition = CGFloat()
    var buttonCenter: CGPoint = .zero
    var currentValue = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(hexString: "#DFFF00")
        self.MainView = UIView(frame: CGRect(origin: self.view.frame.origin, size: self.view.frame.size))
        self.MainView.backgroundColor = UIColor(hexString: "#ECF0F1")
        SetupTableView()
        self.view.addSubview(MainView)
        SetupButtonFrames()
        SetupLabelFrames()
        animateEachLabel()
        SetupViewFrames()
    }
    
    func SetupLabelFrames() {
        self.FirstLabelPosition = 30
        self.welcomeLableFirst = UILabel(frame: CGRect(x: -300, y: self.settingButton.frame.maxY+130, width: 150, height: 40))
        self.welcomeLableFirst.text = "Market"
        self.MainView.addSubview(self.welcomeLableFirst)
        
        self.welcomeLableSecond = UILabel(frame: CGRect(x: -300, y:self.welcomeLableFirst.frame.maxY+20, width: 250, height: 40))
        self.welcomeLableSecond.text = "Your Growth"
        self.MainView.addSubview(self.welcomeLableSecond)
        
        self.welcomeLableThird = UILabel(frame: CGRect(x: -300, y:self.welcomeLableSecond.frame.maxY+20, width: 250, height: 40))
        self.welcomeLableThird.text = "Stategy"
        self.MainView.addSubview(self.welcomeLableThird)
        
        /// Label Properties
        [self.welcomeLableFirst,self.welcomeLableSecond,self.welcomeLableThird].forEach {
            $0?.textColor = UIColor(hexString: "#272D2F")
            $0?.font = UIFont.systemFont(ofSize: 30, weight: .heavy)
        }
        
        /// Create inner view
        self.hexaView = UIView(frame: CGRect(x: 140, y: self.settingButton.frame.maxY+130, width: 50, height: 50))
        self.hexaView.alpha = 0
        self.hexaView.backgroundColor = UIColor(hexString: "#272D2F")
        let maskPath = UIBezierPath(square: self.hexaView.bounds, numberOfSides: 6, cornerRadius: 10.0)
        let maskingLayer = CAShapeLayer()
        maskingLayer.path = maskPath?.cgPath
        self.hexaView.layer.mask = maskingLayer
        self.MainView.addSubview(self.hexaView)
        
        let innerImage = UIImageView(frame: CGRect(x: 5, y: 5, width: 40, height: 40))
        innerImage.image = UIImage(named: "heartbeat")
        innerImage.contentMode = .scaleAspectFit
        self.hexaView.addSubview(innerImage)
    }
    
    func SetupButtonFrames() {
        self.settingButton = UIButton(frame: CGRect(x: 20, y: 60, width: 50, height: 50))
        self.settingButton.setTitle("", for: .normal)
        self.settingButton.setImage(UIImage(named: "settings")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate), for: .normal)
        self.settingButton.tintColor = UIColor(hexString: "#272D2F")
        self.MainView.addSubview(self.settingButton)
    }
    
    func SetupViewFrames() {
        self.bottomButtonView = UIView(frame: CGRect(x: 20, y: self.MainView.bounds.maxY-100, width: 60, height: 60))
        self.bottomButtonView.center.x = self.MainView.center.x
        self.bottomButtonView.layer.cornerRadius = self.bottomButtonView.frame.height/2
        self.bottomButtonView.backgroundColor = UIColor(hexString: "#272D2F")
        self.MainView.addSubview(self.bottomButtonView)
        
        /// Create inner buttons and labels
        self.bottomButtonViewLabel = UILabel(frame: CGRect(x: self.bottomButtonView.bounds.width/2-30, y: self.bottomButtonView.frame.height/2-15, width: self.bottomButtonView.frame.width, height: 30))
        self.bottomButtonViewLabel.text = "Slide to open"
        self.bottomButtonViewLabel.font = UIFont.boldSystemFont(ofSize: 17)
        self.bottomButtonViewLabel.textColor = .white
        self.bottomButtonViewLabel.isHidden = true
        self.bottomButtonView.addSubview(self.bottomButtonViewLabel)
        
        bottomButtonViewInnerButton = UIButton(frame: CGRect(x: self.bottomButtonView.frame.width-60, y: 0, width: 60, height: 60))
        bottomButtonViewInnerButton.backgroundColor = .white
        bottomButtonViewInnerButton.layer.cornerRadius = bottomButtonViewInnerButton.frame.height/2
        bottomButtonViewInnerButton.setTitle("", for: .normal)
        bottomButtonViewInnerButton.setImage(UIImage(named: "arrow"), for: .normal)
        self.bottomButtonView.addSubview(bottomButtonViewInnerButton)
        
        let pan = UIPanGestureRecognizer(target: self, action: #selector(panButton))
        bottomButtonViewInnerButton.addGestureRecognizer(pan)
    }
    
    @objc func panButton(pan: UIPanGestureRecognizer) {
        let loc = pan.location(in: self.bottomButtonView)
        /*
         case possible = 0
         case began = 1
         case changed = 2
         case ended = 3
         case cancelled = 4
         case failed = 5
         */
        if pan.state == .began {
            UIView.animate(withDuration: 0.7) {
                self.settingButton.transform = CGAffineTransform(rotationAngle: CGFloat.pi * 2)
                self.bottomButtonViewInnerButton.frame.origin.x = loc.x
            }
        } else if pan.state == .ended {
            if loc.x <= 131 && loc.x >= 0 {
                UIView.animate(withDuration: 0.7) {
                    self.settingButton.transform = CGAffineTransform(rotationAngle: CGFloat.pi / -2)
                    self.bottomButtonViewInnerButton.frame.origin.x = 0
                }
            } else if loc.x >= 131 {
                UIView.animate(withDuration: 0.7,animations: {
                    self.settingButton.transform = CGAffineTransform(rotationAngle: CGFloat.pi * 2)
                    self.bottomButtonViewInnerButton.frame.origin.x = 130
                }) {_ in
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let viewController = storyboard.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
                    viewController.modalPresentationStyle = .fullScreen
                    self.present(viewController, animated: true)
                }
            }
        } else if pan.state == .changed{
            if loc.x >= 131 || loc.x < 0{
            } else {
                UIView.animate(withDuration: 0.7) {
                    if loc.x < CGFloat(self.currentValue) {
                        self.settingButton.transform = CGAffineTransform(rotationAngle: CGFloat.pi / -2)
                    } else {
                        self.settingButton.transform = CGAffineTransform(rotationAngle: CGFloat.pi * 2)
                    }
                    self.bottomButtonViewInnerButton.frame.origin.x = loc.x
                }
            }
        }
    }
}

// MARK: - Setup TableView
extension ViewController {
    func SetupTableView() {
        self.tableV = UITableView(frame: CGRect(x: 0, y: 50, width: self.view.frame.width, height: self.view.frame.height))
        self.tableV.delegate = self
        self.tableV.dataSource = self
       // self.tableV.separatorStyle = .none
        let nibName = UINib(nibName: "ListTableViewCell", bundle: nil)
        self.tableV.backgroundColor = UIColor.clear
        self.tableV.register(nibName, forCellReuseIdentifier: "ListTableViewCell")
        self.view.addSubview(self.tableV)
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableV.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as! ListTableViewCell
        cell.nameLbl.text = "Mihir"
        cell.nameLbl.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        cell.contentView.backgroundColor = UIColor.clear
        cell.backgroundColor = UIColor.clear
        cell.mainV.backgroundColor = UIColor.clear
        return cell
    }
    
    
}

// MARK: - Animation
extension ViewController {
 
    func animateEachLabel(){
        UIView.animate(withDuration: 1.5, animations: {
            self.welcomeLableFirst.frame.origin.x = self.FirstLabelPosition
        }) {_ in
            UIView.animate(withDuration: 1.5, animations: {
                self.welcomeLableSecond.frame.origin.x = self.welcomeLableFirst.frame.origin.x+40
            }) {_ in
                UIView.animate(withDuration: 1.5, animations: {
                    self.welcomeLableThird.frame.origin.x = self.welcomeLableSecond.frame.origin.x+60
                    self.hexaView.alpha = 1
                }) {_ in
                    UIView.animate(withDuration: 1.5, animations: {
                        self.bottomButtonView.center.x = self.MainView.center.x
                        self.bottomButtonView.bounds.size.width = self.MainView.frame.width/2
                        self.bottomButtonViewLabel.frame.size.width = self.MainView.frame.width
                        self.settingButton.transform = CGAffineTransform(rotationAngle: CGFloat.pi / -2)
                        self.bottomButtonViewLabel.frame.origin.x = self.bottomButtonView.bounds.width/2-30
                    }) {_ in
                        UIView.animate(withDuration: 1.5){
                            self.bottomButtonViewLabel.isHidden = false
                        }
                    }
                }
            }
        }
    }
}
