//
//  HomeViewController.swift
//  AnimationSeries
//
//  Created by Mihir vyas on 28/06/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    ///Create Views
    var MainView: UIView!
    var userImage:UIImageView!
    
    ///User name and Description Labels
    var userName: UILabel!
    var userDescription: UILabel!
    
    ///Notification View
    var firstView: UIView!
    var secondView: UIView!
    var thirdView: UIView!
    var fourthView: UIView!
    
    ///Labels
    var firstViewTopName:UILabel!
    var firstViewTitle:UILabel!
    var firstViewMessage:UILabel!
    var firstViewDate:UILabel!
    var firstNameViewImage: UIImageView!
    
    var secondViewTopName:UILabel!
    var secondViewTitle:UILabel!
    var secondViewMessage:UILabel!
    var secondViewDate:UILabel!
    var secondNameViewImage: UIImageView!
    
    var thirdViewTopName:UILabel!
    var thirdViewTitle:UILabel!
    var thirdViewMessage:UILabel!
    var thirdViewDate:UILabel!
    var thirdNameViewImage: UIImageView!
    
    var fourthViewTopName:UILabel!
    var fourthViewTitle:UILabel!
    var fourthViewMessage:UILabel!
    var fourthViewDate:UILabel!
    var fourthNameViewImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(hexString: "#ECF0F1")
        SetupViews()
    }
    
    func SetupViews() {
        self.MainView = UIView(frame: CGRect(x: 0, y: 0, width: 5, height: 5))
        self.MainView.center = self.view.center
        self.MainView.backgroundColor = UIColor.clear
        self.MainView.layer.borderWidth = 1.7
        self.MainView.layer.cornerRadius = self.MainView.frame.height/2
        self.MainView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
        self.MainView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
        self.MainView.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.MainView.layer.shadowOpacity = 1
        self.MainView.layer.shadowRadius = 1
        self.MainView.layer.masksToBounds = false
        self.view.addSubview(self.MainView)
        
        UIView.animate(withDuration: 0.3, delay: 0.2) {
            self.Animateviews()
        }
    }
    
    func setupUserProfile() {
        let attrs1 = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 24), NSAttributedString.Key.foregroundColor : UIColor(hexString: "#272D2F")]
        let attrs2 = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 24), NSAttributedString.Key.foregroundColor : UIColor.lightGray]
        let attributedString1 = NSMutableAttributedString(string:"Himanshu,\n", attributes:attrs1)
        let attributedString2 = NSMutableAttributedString(string:"you have some important notifications", attributes:attrs2)
        attributedString1.append(attributedString2)
        self.userName = UILabel(frame: CGRect(x: 20, y: self.MainView.frame.maxY+20, width: self.view.frame.width-20, height: 0))
        self.userName.numberOfLines = 0
        self.userName.attributedText = attributedString1
        self.view.addSubview(self.userName)
    }
    
    func SetupDescriptionView() {
        self.firstView = UIView(frame: CGRect(x: 20, y: 240, width: 0, height: 0))
        self.firstView.center.x = self.view.center.x
        self.firstView.layer.borderWidth = 3
        self.firstView.layer.cornerRadius = 4
        self.firstView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
        self.firstView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
        self.firstView.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.firstView.layer.shadowOpacity = 1
        self.firstView.backgroundColor = UIColor.white
        self.firstView.layer.shadowRadius = 1
        self.firstView.layer.masksToBounds = false
        print(self.userName.frame.maxY+30)
        self.view.addSubview(self.firstView)
    }
    
    func setupSecondView(){
        self.secondView = UIView(frame: CGRect(x: 20, y: self.firstView.frame.maxY+20, width: 0, height: 0))
        self.secondView.center.x = self.view.center.x
        self.secondView.layer.borderWidth = 3
        self.secondView.layer.cornerRadius = 4
        self.secondView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
        self.secondView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
        self.secondView.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.secondView.layer.shadowOpacity = 1
        self.secondView.backgroundColor = UIColor.white
        self.secondView.layer.shadowRadius = 1
        self.secondView.layer.masksToBounds = false
        self.view.addSubview(self.secondView)
    }
    
    func setupThirdView(){
        self.thirdView = UIView(frame: CGRect(x: 20, y: self.secondView.frame.maxY+20, width: 0, height: 0))
        self.thirdView.center.x = self.view.center.x
        self.thirdView.layer.borderWidth = 3
        self.thirdView.layer.cornerRadius = 4
        self.thirdView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
        self.thirdView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
        self.thirdView.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.thirdView.layer.shadowOpacity = 1
        self.thirdView.backgroundColor = UIColor.white
        self.thirdView.layer.shadowRadius = 1
        self.thirdView.layer.masksToBounds = false
        self.view.addSubview(self.thirdView)
    }
    
    func setupFourthView(){
        self.fourthView = UIView(frame: CGRect(x: 20, y: self.thirdView.frame.maxY+20, width: 0, height: 0))
        self.fourthView.center.x = self.view.center.x
        self.fourthView.layer.borderWidth = 3
        self.fourthView.layer.cornerRadius = 4
        self.fourthView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
        self.fourthView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
        self.fourthView.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.fourthView.layer.shadowOpacity = 1
        self.fourthView.backgroundColor = UIColor.white
        self.fourthView.layer.shadowRadius = 1
        self.fourthView.layer.masksToBounds = false
        self.view.addSubview(self.fourthView)
    }
    
    func SetupFirstViewDetails() {
        ///UserImage
        self.firstNameViewImage = UIImageView(frame: CGRect(x: self.firstView.frame.minX, y: 10, width: 40, height: 40))
        self.firstNameViewImage.image = UIImage(named: "Kenny")
        self.firstNameViewImage.layer.cornerRadius = self.firstNameViewImage.bounds.width/2
        self.firstNameViewImage.contentMode = .scaleAspectFill
        self.firstNameViewImage.clipsToBounds = true
        self.firstView.addSubview(self.firstNameViewImage)
        
        ///User Name
        self.firstViewTopName = UILabel(frame: CGRect(x: self.firstNameViewImage.frame.maxX+10, y: 15, width: self.firstView.frame.width-20, height: 10))
        self.firstViewTopName.text = "Kendal Jenner"
        self.firstViewTopName.textColor = UIColor.lightGray
        self.firstViewTopName.font = UIFont.systemFont(ofSize: 13, weight: .medium)
        self.firstView.addSubview(self.firstViewTopName)
        
        ///Application Name
        self.firstViewTitle = UILabel(frame: CGRect(x: self.firstNameViewImage.frame.maxX+10, y: self.firstViewTopName.frame.maxY+7, width: self.firstView.frame.width-20, height: 17))
        self.firstViewTitle.text = "Instagram"
        self.firstViewTitle.textColor = UIColor(hexString: "#272D2F")
        self.firstViewTitle.font = UIFont.systemFont(ofSize: 16, weight: .heavy)
        self.firstView.addSubview(self.firstViewTitle)
        
        ///Date
        self.firstViewDate = UILabel(frame: CGRect(x: self.firstView.bounds.width-60, y: 10, width: 50, height: 10))
        self.firstViewDate.text = "Now"
        self.firstViewDate.textAlignment = .right
        self.firstViewDate.textColor = UIColor(hexString: "#272D2F")
        self.firstViewDate.font = UIFont.systemFont(ofSize: 11, weight: .heavy)
        self.firstView.addSubview(self.firstViewDate)
        
        ///Message
        self.firstViewMessage = UILabel(frame: CGRect(x: self.firstNameViewImage.frame.maxX+10, y: self.firstViewTitle.frame.maxY-5, width: self.firstView.frame.size.width-70, height: 50))
        self.firstViewMessage.text = "Happy happiest birthday to my amazing, kind, caring, compassionate, smart buddy..."
        self.firstViewMessage.numberOfLines = 2
        self.firstViewMessage.lineBreakMode = .byWordWrapping
        self.firstViewMessage.textColor = UIColor.lightGray
        self.firstViewMessage.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        self.firstView.addSubview(self.firstViewMessage)
        self.setupSecondView()
    }
    
    func SetupSecondViewDetails() {
        ///UserImage
        self.secondNameViewImage = UIImageView(frame: CGRect(x: self.secondView.frame.minX, y: 10, width: 40, height: 40))
        self.secondNameViewImage.image = UIImage(named: "myntra")
        self.secondNameViewImage.layer.cornerRadius = self.secondNameViewImage.bounds.width/2
        self.secondNameViewImage.contentMode = .scaleAspectFit
        self.secondNameViewImage.clipsToBounds = true
        self.secondView.addSubview(self.secondNameViewImage)
        
        ///User Name
        self.secondViewTopName = UILabel(frame: CGRect(x: self.secondNameViewImage.frame.maxX+10, y: 15, width: self.secondView.frame.width-20, height: 10))
        self.secondViewTopName.text = "Hey, rizz it up! 😎"
        self.secondViewTopName.textColor = UIColor.lightGray
        self.secondViewTopName.font = UIFont.systemFont(ofSize: 13, weight: .medium)
        self.secondView.addSubview(self.secondViewTopName)
        
        ///Application Name
        self.secondViewTitle = UILabel(frame: CGRect(x: self.secondNameViewImage.frame.maxX+10, y: self.secondViewTopName.frame.maxY+7, width: self.secondView.frame.width-20, height: 17))
        self.secondViewTitle.text = "Myntra"
        self.secondViewTitle.textColor = UIColor(hexString: "#272D2F")
        self.secondViewTitle.font = UIFont.systemFont(ofSize: 16, weight: .heavy)
        self.secondView.addSubview(self.secondViewTitle)
        
        ///Date
        self.secondViewDate = UILabel(frame: CGRect(x: self.secondView.bounds.width-60, y: 10, width: 50, height: 10))
        self.secondViewDate.text = "5m ago"
        self.secondViewDate.textAlignment = .right
        self.secondViewDate.textColor = UIColor(hexString: "#272D2F")
        self.secondViewDate.font = UIFont.systemFont(ofSize: 11, weight: .heavy)
        self.secondView.addSubview(self.secondViewDate)
        
        ///Message
        self.secondViewMessage = UILabel(frame: CGRect(x: self.secondNameViewImage.frame.maxX+10, y: self.secondViewTitle.frame.maxY-5, width: self.secondView.frame.size.width-70, height: 50))
        self.secondViewMessage.text = "Feel the force & Vote for New Designs today. Hurry 🎉"
        self.secondViewMessage.numberOfLines = 2
        self.secondViewMessage.lineBreakMode = .byWordWrapping
        self.secondViewMessage.textColor = UIColor.lightGray
        self.secondViewMessage.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        self.secondView.addSubview(self.secondViewMessage)
        self.setupThirdView()
    }
    
    func SetupThirdViewDetails() {
        ///UserImage
        self.thirdNameViewImage = UIImageView(frame: CGRect(x: self.thirdView.frame.minX, y: 10, width: 40, height: 40))
        self.thirdNameViewImage.image = UIImage(named: "Cris")
        self.thirdNameViewImage.layer.cornerRadius = self.thirdNameViewImage.bounds.width/2
        self.thirdNameViewImage.contentMode = .scaleAspectFill
        self.thirdNameViewImage.clipsToBounds = true
        self.thirdView.addSubview(self.thirdNameViewImage)
        
        ///User Name
        self.thirdViewTopName = UILabel(frame: CGRect(x: self.thirdNameViewImage.frame.maxX+10, y: 15, width: self.thirdView.frame.width-20, height: 10))
        self.thirdViewTopName.text = "Cristiano Ronaldo"
        self.thirdViewTopName.textColor = UIColor.lightGray
        self.thirdViewTopName.font = UIFont.systemFont(ofSize: 13, weight: .medium)
        self.thirdView.addSubview(self.thirdViewTopName)
        
        ///Application Name
        self.thirdViewTitle = UILabel(frame: CGRect(x: self.thirdNameViewImage.frame.maxX+10, y: self.thirdViewTopName.frame.maxY+7, width: self.thirdView.frame.width-20, height: 17))
        self.thirdViewTitle.text = "Twitter"
        self.thirdViewTitle.textColor = UIColor(hexString: "#272D2F")
        self.thirdViewTitle.font = UIFont.systemFont(ofSize: 16, weight: .heavy)
        self.thirdView.addSubview(self.thirdViewTitle)
        
        ///Date
        self.thirdViewDate = UILabel(frame: CGRect(x: self.thirdView.bounds.width-60, y: 10, width: 50, height: 10))
        self.thirdViewDate.text = "20m ago"
        self.thirdViewDate.textAlignment = .right
        self.thirdViewDate.textColor = UIColor(hexString: "#272D2F")
        self.thirdViewDate.font = UIFont.systemFont(ofSize: 11, weight: .heavy)
        self.thirdView.addSubview(self.thirdViewDate)
        
        ///Message
        self.thirdViewMessage = UILabel(frame: CGRect(x: self.thirdNameViewImage.frame.maxX+10, y: self.secondViewTitle.frame.maxY-5, width: self.thirdView.frame.size.width-70, height: 50))
        self.thirdViewMessage.text = "NEVER miss a goal 🚨\nFavourite matches and stay up-to-date with..."
        self.thirdViewMessage.numberOfLines = 2
        self.thirdViewMessage.lineBreakMode = .byWordWrapping
        self.thirdViewMessage.textColor = UIColor.lightGray
        self.thirdViewMessage.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        self.thirdView.addSubview(self.thirdViewMessage)
        self.setupFourthView()
    }

    func SetupFourthViewDetails() {
        ///UserImage
        self.fourthNameViewImage = UIImageView(frame: CGRect(x: self.fourthView.frame.minX, y: 10, width: 40, height: 40))
        self.fourthNameViewImage.image = UIImage(named: "Andrew")
        self.fourthNameViewImage.layer.cornerRadius = self.fourthNameViewImage.bounds.width/2
        self.fourthNameViewImage.contentMode = .scaleAspectFill
        self.fourthNameViewImage.clipsToBounds = true
        self.fourthView.addSubview(self.fourthNameViewImage)
        
        ///User Name
        self.fourthViewTopName = UILabel(frame: CGRect(x: self.fourthNameViewImage.frame.maxX+10, y: 15, width: self.fourthView.frame.width-20, height: 10))
        self.fourthViewTopName.text = "Andrew Tate"
        self.fourthViewTopName.textColor = UIColor.lightGray
        self.fourthViewTopName.font = UIFont.systemFont(ofSize: 13, weight: .medium)
        self.fourthView.addSubview(self.fourthViewTopName)
        
        ///Application Name
        self.fourthViewTitle = UILabel(frame: CGRect(x: self.fourthNameViewImage.frame.maxX+10, y: self.fourthViewTopName.frame.maxY+7, width: self.fourthView.frame.width-20, height: 17))
        self.fourthViewTitle.text = "Top G"
        self.fourthViewTitle.textColor = UIColor(hexString: "#272D2F")
        self.fourthViewTitle.font = UIFont.systemFont(ofSize: 16, weight: .heavy)
        self.fourthView.addSubview(self.fourthViewTitle)
        
        ///Date
        self.fourthViewDate = UILabel(frame: CGRect(x: self.fourthView.bounds.width-60, y: 10, width: 50, height: 10))
        self.fourthViewDate.text = "10h ago"
        self.fourthViewDate.textAlignment = .right
        self.fourthViewDate.textColor = UIColor(hexString: "#272D2F")
        self.fourthViewDate.font = UIFont.systemFont(ofSize: 11, weight: .heavy)
        self.fourthView.addSubview(self.fourthViewDate)
        
        ///Message
        print("width:-\(self.fourthView.bounds.width) = \(self.fourthView.frame.maxX)")
        self.fourthViewMessage = UILabel(frame: CGRect(x: self.fourthNameViewImage.frame.maxX+10, y: self.fourthViewTitle.frame.maxY-5, width: self.fourthView.frame.size.width-70, height: 50))
        self.fourthViewMessage.text = "Message: Please just let me know when you are out bro"
        self.fourthViewMessage.numberOfLines = 2
        self.fourthViewMessage.lineBreakMode = .byWordWrapping
        self.fourthViewMessage.textColor = UIColor.lightGray
        self.fourthViewMessage.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        self.fourthView.addSubview(self.fourthViewMessage)
    }
    
}

//MARK: - Animations
extension HomeViewController{
    func Animateviews() {
        UIView.animate(withDuration: 0.3, animations: {
            self.MainView.frame.size.width = 50
            self.MainView.frame.size.height = 50
            self.MainView.frame.origin.x = 20
            self.MainView.frame.origin.y = 55
            self.MainView.layer.cornerRadius = self.MainView.frame.height/2
            self.userImage = UIImageView(frame: self.MainView.bounds)
            self.userImage.image = UIImage(named: "images-2")
            self.userImage.contentMode = .scaleAspectFit
            self.userImage.applyshadowWithCorner(containerView: self.MainView, cornerRadious: self.userImage.bounds.height/2)
            self.MainView.addSubview(self.userImage)
            self.setupUserProfile()
        }) {_ in
            UIView.animate(withDuration: 0.3, animations: {
                self.userName.frame.size.height = 100
                self.SetupDescriptionView()
            }) {_ in
                UIView.animate(withDuration: 0.3, animations: {
                    self.firstView.frame.size.height = 100
                    self.firstView.center.x = self.view.center.x
                }) {_ in
                    UIView.animate(withDuration: 0.3, animations:{
                        self.firstView.frame.size.width = self.view.frame.width-30
                        self.firstView.center.x = self.view.center.x
                    }) {_ in
                        UIView.animate(withDuration: 0.3, animations: {
                            self.SetupFirstViewDetails()
                            
                        }) {_ in
                            UIView.animate(withDuration: 0.3, animations: {
                                self.secondView.frame.size.height = 100
                                self.secondView.center.x = self.view.center.x
                            }) {_ in
                                UIView.animate(withDuration: 0.3, animations:{
                                    self.secondView.frame.size.width = self.view.frame.width-30
                                    self.secondView.center.x = self.view.center.x
                                }) {_ in
                                    UIView.animate(withDuration: 0.3, animations: {
                                        self.SetupSecondViewDetails()
                                    }) {_ in
                                        UIView.animate(withDuration: 0.3, animations: {
                                            self.thirdView.frame.size.height = 100
                                            self.thirdView.center.x = self.view.center.x
                                        }) {_ in
                                            UIView.animate(withDuration: 0.3, animations:{
                                                self.thirdView.frame.size.width = self.view.frame.width-30
                                                self.thirdView.center.x = self.view.center.x
                                            }) {_ in
                                                UIView.animate(withDuration: 0.3, animations: {
                                                    self.SetupThirdViewDetails()
                                                }) {_ in
                                                    UIView.animate(withDuration: 0.3, animations: {
                                                        self.fourthView.frame.size.height = 100
                                                        self.fourthView.center.x = self.view.center.x
                                                    }) {_ in
                                                        UIView.animate(withDuration: 0.3, animations:{
                                                            self.fourthView.frame.size.width = self.view.frame.width-30
                                                            self.fourthView.center.x = self.view.center.x
                                                        }) {_ in
                                                            UIView.animate(withDuration: 0.3, animations: {
                                                                self.SetupFourthViewDetails()
                                                            })
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
