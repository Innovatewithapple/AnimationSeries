//
//  ListViewController.swift
//  AnimationSeries
//
//  Created by Mihir vyas on 28/06/23.
//

import UIKit

class ListViewController: UIViewController {
    
    ///Custom Transparent Images
    var TopCornerImage:UIImageView!
    var BottomCornerImage:UIImageView!
    
    ///Clock View
    var clockView:ClockFace!
    var clockFaceImage:UIImageView!
    
    ///Custom Labels
    var WelcomeLabel: UILabel!
    var emailLabel: UILabel!
    var passwordLabel: UILabel!
    var otpLabel: UILabel!
    var EmailIDLabel:UILabel!
    
    ///Custom TextField
    var emailTextField: UITextField!
    var passwordTextField: UITextField!
    var otpTextField:UITextField!
    
    ///Custom Views
    var EmailFieldView:UIView!
    var PasswordFieldView:UIView!
    var otpFieldView:UIView!
    var LetsGoButtonView:UIView!

    ///Custom ImageView
    var emailFieldImage:UIImageView!
    var passwordFieldImage:UIImageView!
    
    ///Custom Buttons
    var letsGoButton:UIButton!
    
    ///Login Success View
    var loginSuccessView: UIView!
    var loginSuccessMessage: UILabel!
    
    var isPasswordVisible = false
    var second = 0
    var isButtonType = 0
    
    enum BottomButtonType: Int {
        case LoginIn = 0
        case OTP = 1
        case Resend = 2
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(hexString: "#ECF0F1")
        SetupTransparentImage()
        SetupLabels()
        SetupViews()
    }
    
    func SetupTransparentImage() {
        self.BottomCornerImage = UIImageView(frame: CGRect(x: 20, y: 60, width: 50, height: 50))
        self.BottomCornerImage.image = UIImage(named: "settings")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        self.BottomCornerImage.tintColor = UIColor(hexString: "#272D2F")
        self.BottomCornerImage.rotate360Degrees()
        self.view.addSubview(self.BottomCornerImage)
    }
    
    func SetupLabels() {
        self.WelcomeLabel = UILabel(frame: CGRect(x: self.view.bounds.minX+30, y: self.BottomCornerImage.frame.maxY+50, width: self.view.bounds.width-30, height: 80))
        let welcomeText = NSMutableAttributedString(string: "Welcome,\nsign in to continue...")
        self.WelcomeLabel.numberOfLines = 0
        self.WelcomeLabel.font = UIFont.systemFont(ofSize: 25, weight: .semibold)
        self.WelcomeLabel.textColor = UIColor(hexString: "#272D2F")
        self.WelcomeLabel.attributedText = welcomeText
        self.view.addSubview(self.WelcomeLabel)
        
    }
    
        func SetupViews() {
            ///Add emailId label to show email after button action
            ///width: self.view.bounds.width-70
            self.EmailIDLabel = UILabel(frame: CGRect(x: self.view.bounds.minX+50, y: self.WelcomeLabel.frame.maxY+30, width: 0, height: 50))
            self.EmailIDLabel.text = "Email"
            self.EmailIDLabel.font = UIFont.systemFont(ofSize: 17, weight: .medium)
            self.EmailIDLabel.textColor = UIColor(hexString: "#272D2F")
            self.EmailIDLabel.isHidden = true
            self.view.addSubview(self.EmailIDLabel)
            
            ///Add email view
            self.EmailFieldView = UIView(frame: CGRect(x: self.view.bounds.minX+30, y: self.WelcomeLabel.frame.maxY+30, width: self.view.bounds.width-70, height: 50))
            self.EmailFieldView.center.x = self.view.center.x
            self.EmailFieldView.backgroundColor = UIColor.white
            self.EmailFieldView.layer.borderWidth = 3
            self.EmailFieldView.layer.cornerRadius = 4
            self.EmailFieldView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
            self.EmailFieldView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
            self.EmailFieldView.layer.shadowOffset = CGSize(width: 5, height: 5)
            self.EmailFieldView.layer.shadowOpacity = 1
            self.EmailFieldView.layer.shadowRadius = 1
            self.EmailFieldView.layer.masksToBounds = false
            self.view.addSubview(self.EmailFieldView)
            
            ///Add password view
            self.PasswordFieldView = UIView(frame: CGRect(x: self.view.bounds.minX+30, y: self.EmailFieldView.frame.maxY+20, width: self.view.bounds.width-70, height: 50))
            self.PasswordFieldView.center.x = self.view.center.x
            self.PasswordFieldView.backgroundColor = UIColor.white
            self.PasswordFieldView.layer.borderWidth = 3
            self.PasswordFieldView.layer.cornerRadius = 4
            self.PasswordFieldView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
            self.PasswordFieldView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
            self.PasswordFieldView.layer.shadowOffset = CGSize(width: 5, height: 5)
            self.PasswordFieldView.layer.shadowOpacity = 1
            self.PasswordFieldView.layer.shadowRadius = 1
            self.PasswordFieldView.layer.masksToBounds = false
            self.view.addSubview(self.PasswordFieldView)
            
            ///Add OTP view
            /////height: 50
            self.otpFieldView = UIView(frame: CGRect(x: self.view.bounds.minX+30, y: self.WelcomeLabel.frame.maxY+40, width: self.view.bounds.width-70, height: 0))
            self.otpFieldView.center.x = self.view.center.x
            self.otpFieldView.backgroundColor = UIColor.white
            self.otpFieldView.layer.borderWidth = 3
            self.otpFieldView.layer.cornerRadius = 4
            self.otpFieldView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
            self.otpFieldView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
            self.otpFieldView.layer.shadowOffset = CGSize(width: 5, height: 5)
            self.otpFieldView.layer.shadowOpacity = 1
            self.otpFieldView.layer.shadowRadius = 1
            self.otpFieldView.layer.masksToBounds = false
            self.view.addSubview(self.otpFieldView)
            SetupEmailAndPasswordLabel()
    }

    func SetupEmailAndPasswordLabel() {
        ///Add email label
        self.emailLabel = UILabel(frame: CGRect(x: self.EmailFieldView.bounds.minX+10, y: self.EmailFieldView.bounds.minY+2.5, width: self.EmailFieldView.bounds.width-10, height: self.EmailFieldView.bounds.height-5))
        self.emailLabel.text = "Email"
        self.emailLabel.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        self.emailLabel.textColor = UIColor(hexString: "#272D2F")
        self.EmailFieldView.addSubview(self.emailLabel)
        
        ///Add password label
        self.passwordLabel = UILabel(frame: CGRect(x: self.PasswordFieldView.bounds.minX+10, y: self.PasswordFieldView.bounds.minY+2.5, width: self.PasswordFieldView.bounds.width-10, height: self.PasswordFieldView.bounds.height-5))
        self.passwordLabel.text = "Password"
        self.passwordLabel.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        self.passwordLabel.textColor = UIColor(hexString: "#272D2F")
        self.PasswordFieldView.addSubview(self.passwordLabel)
        
        ///Add OTP label
        ///height: self.otpFieldView.bounds.height-5
        self.otpLabel = UILabel(frame: CGRect(x: self.otpFieldView.bounds.minX+10, y: self.otpFieldView.bounds.minY+2.5, width: self.otpFieldView.bounds.width-10, height: 0))
        self.otpLabel.text = "OTP"
        self.otpLabel.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        self.otpLabel.textColor = UIColor(hexString: "#272D2F")
        self.otpFieldView.addSubview(self.otpLabel)
        
        SetupEmailAndPasswordTextField()
    }
    
    func SetupEmailAndPasswordTextField() {
        ///Add email text field
        self.emailTextField = UITextField(frame: CGRect(x: self.EmailFieldView.bounds.minX+10, y: self.EmailFieldView.bounds.minY+2.5, width: self.EmailFieldView.bounds.width-10, height: self.EmailFieldView.bounds.height-5))
        self.emailTextField.borderStyle = .none
        self.emailTextField.delegate = self
        self.emailTextField.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        self.emailTextField.textColor = UIColor(hexString: "#272D2F")
        self.EmailFieldView.addSubview(self.emailTextField)
        
        ///Add password text field
        self.passwordTextField = UITextField(frame: CGRect(x: self.PasswordFieldView.bounds.minX+10, y: self.PasswordFieldView.bounds.minY+2.5, width: self.PasswordFieldView.bounds.width-50, height: self.PasswordFieldView.bounds.height-5))
        self.passwordTextField.borderStyle = .none
        self.passwordTextField.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        self.passwordTextField.delegate = self
        self.passwordTextField.isSecureTextEntry = true
        self.passwordTextField.textColor = UIColor(hexString: "#272D2F")
        self.PasswordFieldView.addSubview(self.passwordTextField)
        
        ///Add OTP text field
        ///height: self.otpFieldView.bounds.height-5
        self.otpTextField = UITextField(frame: CGRect(x: self.otpFieldView.bounds.minX+10, y: self.otpFieldView.bounds.minY+2.5, width: self.otpFieldView.bounds.width-50, height: 0))
        self.otpTextField.borderStyle = .none
        self.otpTextField.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        self.otpTextField.delegate = self
        self.otpTextField.isSecureTextEntry = false
        self.otpTextField.keyboardType = .numberPad
        self.otpTextField.textColor = UIColor(hexString: "#272D2F")
        self.otpFieldView.addSubview(self.otpTextField)
        
        SetupEmailAndPasswordIcons()
    }
    
    func SetupEmailAndPasswordIcons() {
        ///Add email field icon
        ///UIImageView(frame: CGRect(x: self.EmailFieldView.bounds.maxX-35, y: 12, width: 25, height: 25))
        self.emailFieldImage = UIImageView(frame: CGRect(x: self.EmailFieldView.bounds.maxX-35, y: self.EmailFieldView.bounds.maxY-20, width: 5, height: 5))
        self.emailFieldImage.image = UIImage(named: "tick")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        self.emailFieldImage.tintColor = UIColor(hexString: "#272D2F")
        self.emailFieldImage.isHidden = true
        self.emailFieldImage.layer.cornerRadius = self.emailFieldImage.bounds.height/2
      //  self.emailFieldImage.backgroundColor = UIColor(hexString: "#272D2F")
        self.EmailFieldView.addSubview(self.emailFieldImage)
        
        ///Add password field icon
        self.passwordFieldImage = UIImageView(frame: CGRect(x: self.PasswordFieldView.bounds.maxX-35, y: 12, width: 25, height: 25))
        self.passwordFieldImage.isHidden = true
        self.passwordFieldImage.image = UIImage(named: "password")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        self.passwordFieldImage.tintColor = UIColor(hexString: "#272D2F")
        let passwordTap = UITapGestureRecognizer(target: self, action: #selector(passwordImageAction))
        self.passwordFieldImage.addGestureRecognizer(passwordTap)
        self.passwordFieldImage.isUserInteractionEnabled = true
        self.PasswordFieldView.addSubview(self.passwordFieldImage)
        SetupButtons()
    }
    
    func SetupButtons() {
        ///Add Button View
        self.LetsGoButtonView = UIView(frame: CGRect(x: self.view.bounds.width/2-30, y: self.PasswordFieldView.frame.maxY+40, width: self.view.bounds.width-170, height: 50))
        self.LetsGoButtonView.center.x = self.view.center.x
        self.LetsGoButtonView.backgroundColor = UIColor.white
        self.LetsGoButtonView.layer.borderWidth = 3
        self.LetsGoButtonView.layer.cornerRadius = 4
        self.LetsGoButtonView.layer.borderColor = UIColor(hexString: "#272D2F").cgColor
        self.LetsGoButtonView.layer.shadowColor = UIColor(hexString: "#272D2F").cgColor
        self.LetsGoButtonView.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.LetsGoButtonView.layer.shadowOpacity = 1
        self.LetsGoButtonView.layer.shadowRadius = 1
        self.LetsGoButtonView.layer.masksToBounds = false
        self.view.addSubview(self.LetsGoButtonView)
        
        ///Add Label
        self.letsGoButton = UIButton(frame: CGRect(origin: self.LetsGoButtonView.bounds.origin, size: self.LetsGoButtonView.bounds.size))
        self.letsGoButton.setTitle("Let's go", for: .normal)
        self.letsGoButton.setTitleColor(UIColor(hexString: "#272D2F"), for: .normal)
        self.letsGoButton.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        self.letsGoButton.setImage(nil, for: .normal)
        self.letsGoButton.addTarget(self, action: #selector(LetsGoAction), for: .touchUpInside)
        self.LetsGoButtonView.addSubview(self.letsGoButton)
        self.SetupClockFace()
    }
    
    func SetupClockFace() {
        self.clockFaceImage = UIImageView(frame: CGRect(x: self.view.frame.maxX-70, y: self.WelcomeLabel.frame.maxY+45, width: 40, height: 40))
        self.clockFaceImage.image = UIImage(named: "stopwatch")
        self.clockFaceImage.contentMode = .scaleAspectFit
        self.clockFaceImage.isHidden = true
        self.view.addSubview(self.clockFaceImage)
        
        self.clockView = ClockFace(frame: CGRect(x: self.clockFaceImage.center.x, y: self.clockFaceImage.center.y, width: 30, height: 30))
        self.clockView.backgroundColor = UIColor.clear
        self.clockView.center.x = self.clockFaceImage.center.x
        self.clockView.center.y = self.clockFaceImage.center.y+2
        self.clockView.isHidden = true
        self.view.addSubview(self.clockView)
        SetupLoginSuccessView()
    }
    
    func SetupLoginSuccessView() {
        ///Create login success view
        self.loginSuccessView = UIView(frame: CGRect(x: 0, y: self.view.center.y, width: self.view.frame.width, height: 1))
        self.loginSuccessView.backgroundColor  = UIColor(hexString: "#272D2F")
        self.loginSuccessView.isHidden = true
        self.view.addSubview(self.loginSuccessView)
        
        ///Create login message
        self.loginSuccessMessage = UILabel(frame: CGRect(x: 0, y: self.view.center.y-25, width: 0, height: 50))
        self.loginSuccessMessage.text = "Logged In"
        self.loginSuccessMessage.font = UIFont.systemFont(ofSize: 30, weight: .heavy)
        self.loginSuccessMessage.textColor = UIColor(hexString: "#ECF0F1")
        self.loginSuccessMessage.textAlignment = .center
        self.loginSuccessView.addSubview(loginSuccessMessage)
    }
}

//MARK: - TextField Delegates
extension ListViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.emailTextField {
            UIView.animate(withDuration: 0.8) {
                self.emailLabel.frame.size.width = 0
            }
        } else if textField == self.passwordTextField {
            UIView.animate(withDuration: 0.8, animations: {
                self.passwordLabel.frame.size.width = 0
            }) {_ in
                UIView.animate(withDuration: 0.4) {
                    self.passwordFieldImage.isHidden = false
                }
            }
        } else if textField == self.otpTextField {
            UIView.animate(withDuration: 0.8) {
                self.otpLabel.frame.size.width = 0
            }
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.emailTextField {
            if self.emailTextField.text == "" {
                UIView.animate(withDuration: 0.8) {
                    self.emailLabel.frame.size.width = self.EmailFieldView.bounds.width-10
                }
            }
        } else if textField == self.passwordTextField {
            if self.passwordTextField.text == "" {
                UIView.animate(withDuration: 0.8,animations:  {
                    self.passwordLabel.frame.size.width = self.PasswordFieldView.bounds.width-10
                }) {_ in
                    let checkValidEmail = self.isValidEmail(testStr: self.emailTextField.text ?? "")
                    if checkValidEmail == false {
                        UIView.animate(withDuration: 0.4)  {
                            self.emailFieldImage.image = UIImage(named: "cross")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
                            self.emailFieldImage.tintColor = UIColor(hexString: "#272D2F")
                            self.emailFieldImage.isHidden = false
                            self.emailFieldImage.frame.size.width = 25
                            self.emailFieldImage.frame.size.height = 25
                            self.emailFieldImage.frame.origin.y = 12
                        }
                    } else {
                        UIView.animate(withDuration: 0.4)  {
                            self.emailFieldImage.image = UIImage(named: "tick")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
                            self.emailFieldImage.tintColor = UIColor(hexString: "#272D2F")
                            self.emailFieldImage.isHidden = false
                            self.emailFieldImage.frame.size.width = 25
                            self.emailFieldImage.frame.size.height = 25
                            self.emailFieldImage.frame.origin.y = 12
                        }
                    }
                }
            }
        } else if textField == otpTextField {
            
        }
    }
    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if textField == self.emailTextField {
            let checkValidEmail = self.isValidEmail(testStr: textField.text ?? "")
            if checkValidEmail == false {
                UIView.animate(withDuration: 0.4, animations:  {
                    self.emailFieldImage.image = UIImage(named: "cross")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
                    self.emailFieldImage.tintColor = UIColor(hexString: "#272D2F")
                    self.emailFieldImage.isHidden = false
                    
                }) {_ in
                    UIView.animate(withDuration: 0.4){
                        self.emailFieldImage.frame.size.width = 25
                        self.emailFieldImage.frame.size.height = 25
                        self.emailFieldImage.frame.origin.y = 12
                    }
                }
            } else {
                UIView.animate(withDuration: 0.4, animations:  {
                    self.emailFieldImage.frame.size.width = 5
                    self.emailFieldImage.frame.size.height = 5
                    self.emailFieldImage.frame.origin.y = self.EmailFieldView.bounds.maxY-20
                }) {_ in
                    UIView.animate(withDuration: 0.4,animations:{
                        self.emailFieldImage.image = UIImage(named: "tick")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
                        self.emailFieldImage.tintColor = UIColor(hexString: "#272D2F")
                        self.emailFieldImage.isHidden = false
                    }) {_ in
                        self.emailFieldImage.frame.size.width = 25
                        self.emailFieldImage.frame.size.height = 25
                        self.emailFieldImage.frame.origin.y = 12
                    }
                }
            }
        } else if textField == otpTextField {
            if textField.text?.count ?? 0 >= 6 {
                UIView.animate(withDuration: 0.3, animations: {
                    self.otpTextField.resignFirstResponder()
                }) {_ in
                    UIView.animate(withDuration: 0.5, delay: 0.2,animations:{
                        self.letsGoButton.setTitle("Check", for: .normal)
                        self.LetsGoButtonView.frame.size.height = 50
                    }) {_ in
                        UIView.animate(withDuration: 0.4){
                            self.letsGoButton.isHidden = false
                        }
                    }
                }
            } else if textField.text ?? "" == "" {
                UIView.animate(withDuration: 0.5) {
                    self.letsGoButton.isHidden = true
                    self.LetsGoButtonView.frame.size.height = 0
                    //self.otpLabel.frame.size.height = self.otpFieldView.bounds.height-5
                }
            } else if textField.text?.count ?? 0 <= 5{
                UIView.animate(withDuration: 0.5){
                    self.letsGoButton.isHidden = true
                    self.LetsGoButtonView.frame.size.height = 0
                }
            }
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == otpTextField {
            let maxLength = 6
            let currentString = (textField.text ?? "") as NSString
            let newString = currentString.replacingCharacters(in: range, with: string)
            
            return newString.count <= maxLength
        } else {
            return true
        }
    }
    
}

//MARK: - Check if inserted email is valied or not
extension ListViewController{
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }

}

//MARK: - Viewcontroller actions
extension ListViewController {
    ///Stop Watch Action
    @objc func timerFired(_ timer: Timer?) {
        if self.second == 60 {
            clockView.setTime(60)
            self.otpTextField.resignFirstResponder()
            timer?.invalidate()
            self.otpTextField.text = ""
                UIView.animate(withDuration: 0.3, animations: {
                    self.otpLabel.frame.size.width = self.otpFieldView.bounds.width-10
                }) {_ in
                    UIView.animate(withDuration: 0.5, delay: 0.2,animations:{
                        self.LetsGoButtonView.frame.size.height = 50
                    }) {_ in
                        UIView.animate(withDuration: 0.4){
                            self.letsGoButton.setTitle("Resend", for: .normal)
                            self.letsGoButton.isHidden = false
                            self.isButtonType = 2
                        }
                    }
                }
        } else {
            self.second = self.second + 3
            clockView.setTime(self.second)
            if self.second > 50 && self.second < 60 {
                self.clockView.flash(numberOfFlashes: 5)
                self.clockFaceImage.flash(numberOfFlashes: 5)
            }
        }
    }
    
    ///Let's go Button Action
    @objc func LetsGoAction(_ sender: UIButton) {
        var checkType = BottomButtonType(rawValue: self.isButtonType)!
        switch checkType {
        case .LoginIn:
            print("login")
            self.checkLoginButton()
        case .OTP:
            print("OTP")
            self.checkOTPButton()
        case .Resend:
            print("Resend")
            checkResendButton()
        }
    }
    
    ///Password Icon Action
    @objc func passwordImageAction(){
    print("touch")
    if self.isPasswordVisible == false {
        UIView.animate(withDuration: 0.3) {
            self.passwordFieldImage.image = UIImage(named: "passwordUnlock")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
            self.passwordFieldImage.tintColor = UIColor(hexString: "#272D2F")
            self.passwordTextField.isSecureTextEntry = false
            self.isPasswordVisible = true
        }
    } else {
        UIView.animate(withDuration: 0.3) {
            self.passwordFieldImage.image = UIImage(named: "password")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
            self.passwordFieldImage.tintColor = UIColor(hexString: "#272D2F")
            self.passwordTextField.isSecureTextEntry = true
            self.isPasswordVisible = false
        }
    }
}
}


//MARK: - Handle ButtonAction Conditions
extension ListViewController {
    func checkLoginButton(){
        let checkValidEmail = self.isValidEmail(testStr: self.emailTextField.text ?? "")
        if self.emailTextField.text == "" || checkValidEmail == false{
            UIView.animate(withDuration: 0.5) {
                self.EmailFieldView.flash(numberOfFlashes: 2)
            }
            return
        } else if self.passwordTextField.text == "" {
            UIView.animate(withDuration: 0.5) {
                self.PasswordFieldView.flash(numberOfFlashes: 2)
            }
            return
        } else if self.emailTextField.text == "" && passwordTextField.text == "" {
            UIView.animate(withDuration: 0.5) {
                self.EmailFieldView.flash(numberOfFlashes: 2)
                self.PasswordFieldView.flash(numberOfFlashes: 2)
            }
            return
        }
        self.isButtonType = 1
        UIView.animate(withDuration: 0.3,animations: {
            self.LetsGoButtonView.layer.shadowOpacity = 0
        }) {_ in
            UIView.animate(withDuration: 0.3, animations: {
                self.LetsGoButtonView.layer.shadowOpacity = 1
            }) {_ in
                UIView.animate(withDuration: 0.8, animations:{
                    self.WelcomeLabel.frame.size.height = 90
                    self.WelcomeLabel.text = "For authentication, \nwe have sent otp to your\naccount..."
                    self.emailFieldImage.isHidden = true
                    self.passwordFieldImage.isHidden = true
                }) {_ in
                    UIView.animate(withDuration: 0.8,animations: {
                        self.passwordTextField.frame.size.width = 0
                        self.emailTextField.frame.size.width = 0
                        self.EmailFieldView.frame.size.width = 0
                        self.PasswordFieldView.frame.size.width = 0
                    }) {_ in
                        UIView.animate(withDuration: 0.5,delay: 0.2, animations: {
                            self.otpFieldView.frame.size.height = 50
                            self.otpLabel.frame.size.height = self.otpFieldView.bounds.height-5
                            self.letsGoButton.isHidden = true
                            self.LetsGoButtonView.frame.size.height = 0
                            self.otpTextField.frame.size.height = self.otpFieldView.bounds.height-5
                        }) {_ in
                            UIView.animate(withDuration: 0.5, animations:{
                                self.otpFieldView.frame.size.width = self.otpFieldView.bounds.width-50
                            }) {_ in
                                UIView.animate(withDuration: 0.5, animations: {
                                    self.clockFaceImage.isHidden = false
                                    self.clockView.isHidden = false
                                }){_ in
                                    UIView.animate(withDuration: 0.4, delay: 0.3) {
                                        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.timerFired(_:)), userInfo: nil, repeats: true)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    func checkOTPButton() {
        self.isButtonType = 1
        UIView.animate(withDuration: 0.4, animations: {
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewcontroller = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            viewcontroller.modalPresentationStyle = .fullScreen
            self.present(viewcontroller, animated: true)
        })
    }
    
    func checkResendButton () {
        self.isButtonType = 1
        UIView.animate(withDuration: 0.5, animations: {
            self.letsGoButton.setTitle("Check", for: .normal)
            self.letsGoButton.isHidden = true
            self.LetsGoButtonView.frame.size.height = 0
        }) {_ in
            UIView.animate(withDuration: 0.3, delay: 0.2) {
                self.second = 0
                Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.timerFired(_:)), userInfo: nil, repeats: true)
            }
        }
    }
}
