//
//  DetailsViewController.swift
//  CardsAnimation
//
//  Created by Mihir vyas on 09/07/23.
//

import UIKit

class DetailsViewController: UIViewController {
    
    ///CardView
    var cardView: UIView!
    var bottomView: UIView!
    
    var cardNumber: UILabel!
    var cardLogo:UIButton!
    var cardTypeImage:UIImageView!
    var cardHolderName:UILabel!
    var cardExpiryLabel: UILabel!
    var copyButton:UIButton!
    var withdrawalLabel: UILabel!
    var limitLabel: UILabel!
    var switchButton: UISwitch!
    var ActiveLabel: UILabel!
    var InActiveView: UIView!
    var EditButton: UIButton!
    var UnderLineView: UIView!
    var CardHolderNameField: UITextField!
    var CardHolderNameFieldUnderLine: UIView!
    
    var CardDataDetails = CardModel()
    ///Apply Methods
    var backgroundColor = String()
    var cardBackgroundColor = String()
    var cardShadowColor = String()
    var cardBottomColor = String()
    var holderName = String()
    var expire = String()
    var typeImage = String()
    var cardNumberText = String()
    var cvv = String()
    var withdrawal = String()
    var index = 0
    var statusBarColor = String()
    var typeOfCard = false
    var BottomButtonTypeEdit = false
    
    ///SecondTypeView
    var secondTypeCard: UIView!
    var SideImage: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(hexString: "\(self.CardDataDetails.cardBackgroundColor)")//#AFD6EF
        let directions: [UISwipeGestureRecognizer.Direction] = [.left, .right]
        for direction in directions {
            let gesture = UISwipeGestureRecognizer(target: self, action: #selector(swipeCardsAction))
            gesture.direction = direction
            self.view.addGestureRecognizer(gesture)
        }
        SetupStatusBar(color: self.statusBarColor)
        self.setupCardView()
    }
    
    @objc func swipeCardsAction(sender: UISwipeGestureRecognizer) {
        print(sender.direction)
       if sender.direction == .left {
           UIView.animate(withDuration: 0.2, animations:  {
               let storyboard = UIStoryboard(name: "Main", bundle: nil)
               let vc = storyboard.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
               if self.index == CardData.count-1{
                   vc.CardDataDetails = CardData[0]
                   vc.index = 0
                   vc.statusBarColor = CardData[0].shadowcolor
                   vc.modalPresentationStyle = .custom
                   vc.modalTransitionStyle = .crossDissolve
                   self.present(vc, animated: true)
               } else {
                   vc.CardDataDetails = CardData[self.index+1]
                   vc.statusBarColor = CardData[self.index+1].shadowcolor
                   vc.index = self.index+1
                   vc.modalPresentationStyle = .custom
                   vc.modalTransitionStyle = .crossDissolve
                   self.present(vc, animated: true)
               }
               
           })
       } else if sender.direction == .right {
           let storyboard = UIStoryboard(name: "Main", bundle: nil)
           let vc = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
           CardData.removeAll()
           vc.modalPresentationStyle = .custom
           vc.modalTransitionStyle = .crossDissolve
           self.present(vc, animated: true)
       }
    }

    func setupCardView() {
        self.cardView = UIView(frame: CGRect(x: 0, y: 50, width: Int(self.view.frame.width)-30, height: 230))
        self.cardView.center.x = self.view.center.x
        self.cardView.layer.cornerRadius = 12
        self.cardView.layer.masksToBounds = true
        self.cardView.backgroundColor = UIColor(hexString: "\(self.CardDataDetails.cardBackgroundColor)")//C0D9F0
        self.cardView.layer.shadowColor = UIColor(hexString: self.CardDataDetails.shadowcolor).cgColor //52A8E1
        self.cardView.layer.shadowOpacity = 1
        self.cardView.layer.shadowOffset = CGSize(width: 0.5, height: 0.4)
        self.cardView.layer.shadowRadius = 6.0
        self.cardView.layer.masksToBounds = false
        self.cardView.isHidden = false
        self.view.addSubview(self.cardView)
        setupCardLogo()
        addSwipe()
    }

    
    func setupCardLogo() {
        self.cardLogo = UIButton(frame: CGRect(x: 30, y: self.cardView.frame.origin.y-20, width: 50, height: 45))
        self.cardLogo.setTitle("", for: .normal)
        self.cardLogo.setImage(UIImage(named: "inifnity")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate), for: .normal)
        self.cardLogo.tintColor = UIColor(hexString: self.CardDataDetails.CompanyImagecolor)
        self.cardView.addSubview(self.cardLogo)
        setupBottomView()
    }
    
    func setupBottomView() {
        self.bottomView = UIView(frame: CGRect(x: 0, y: Int(self.cardView.frame.maxY)-130, width: Int(self.view.frame.width)-30, height: 80))
        self.bottomView.layer.cornerRadius = 10
        self.bottomView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        self.bottomView.backgroundColor = UIColor(hexString: self.CardDataDetails.cardbottomColor)
        self.cardView.addSubview(self.bottomView)
        setupCardNumber()
    }
    
    func setupCardNumber() {
        self.cardNumber = UILabel(frame: CGRect(x: 0, y: self.cardLogo.bounds.maxY+50, width: self.view.frame.width-30, height: 40))
        self.cardNumber.text = self.CardDataDetails.cardNumber
        self.cardNumber.textColor = UIColor(hexString: self.CardDataDetails.cardnumberColor)
        self.cardNumber.textAlignment = .center
        self.cardNumber.font = UIFont.systemFont(ofSize: 18.0, weight: .black)
        self.cardView.addSubview(self.cardNumber)
        setupCardTypeImage()
    }
    
    func setupCardTypeImage() {
        self.cardTypeImage = UIImageView(frame: CGRect(x: self.bottomView.bounds.maxX-70, y: 15, width: 50, height: 50))
        self.cardTypeImage.image = self.CardDataDetails.cardtypeImage
        self.bottomView.addSubview(self.cardTypeImage)
        setupCardDateAndName()
    }
    
    func setupCardDateAndName() {
        self.cardHolderName = UILabel(frame: CGRect(x: 20, y: 10, width: self.bottomView.bounds.width-80, height: 40))
        self.cardHolderName.text = self.CardDataDetails.cardName
        self.cardHolderName.font = UIFont.systemFont(ofSize: 18.0, weight: .bold)
        self.cardHolderName.textColor = UIColor(hexString: self.CardDataDetails.cardNameColor)
        self.bottomView.addSubview(self.cardHolderName)
        
        self.cardExpiryLabel = UILabel(frame: CGRect(x: 20, y: self.cardHolderName.bounds.maxY-4, width: self.bottomView.bounds.width-80, height: 40))
        self.cardExpiryLabel.text = self.CardDataDetails.cardExpire
        self.cardExpiryLabel.textColor = UIColor(hexString: self.CardDataDetails.cardNameColor)
        self.cardExpiryLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .bold)
        self.bottomView.addSubview(self.cardExpiryLabel)
        setupCopyButton()
    }
    
    func setupCopyButton() {
        self.copyButton = UIButton(frame: CGRect(x: self.cardView.bounds.maxX-60, y: self.cardNumber.center.y-12.5, width: 25, height: 25))
        self.copyButton.setTitle("", for: .normal)
        self.copyButton.setImage(UIImage(named: "copy")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate), for: .normal)
        self.copyButton.tintColor = UIColor(hexString: self.CardDataDetails.shadowcolor)
        self.cardView.addSubview(self.copyButton)
        setupWithdrawal()
    }
    
    func setupWithdrawal() {
        self.withdrawalLabel = UILabel(frame: CGRect(x: 20, y: self.cardView.frame.maxY+40, width: 100, height: 30))
        self.withdrawalLabel.text = "WITHDRAWAL"
        self.withdrawalLabel.textColor = UIColor(hexString: self.CardDataDetails.cardnumberColor)
        self.withdrawalLabel.font = UIFont.systemFont(ofSize: 13.0, weight: .thin)
        self.view.addSubview(self.withdrawalLabel)
        setupLimit()
    }
    
    func setupLimit() {
        self.limitLabel = UILabel(frame: CGRect(x: 0, y: self.withdrawalLabel.frame.maxY+10, width: self.view.frame.width, height: 30))
        self.limitLabel.text = self.CardDataDetails.withdrawal
        self.limitLabel.textColor = UIColor(hexString: self.CardDataDetails.cardnumberColor)
        self.limitLabel.textAlignment = .center
        self.limitLabel.font = UIFont.systemFont(ofSize: 25.0, weight: .medium)
        self.view.addSubview(self.limitLabel)
        setupStatus()
    }
    
    func setupStatus() {
        self.switchButton = UISwitch(frame: CGRect(x: self.view.bounds.width-70, y: self.cardView.frame.maxY+10, width:50 , height: 30))
       // self.switchButton.center.x = self.view.center.x
        self.switchButton.isSelected = true
        self.switchButton.isOn = true
        self.switchButton.onTintColor = UIColor.green
        self.switchButton.addTarget(self, action: #selector(ActiveDetactiveCard), for: .valueChanged)
        self.view.addSubview(self.switchButton)
        setupActiveLabel()
    }
    
    func setupActiveLabel() {
        self.ActiveLabel = UILabel(frame: CGRect(x: self.view.bounds.width-70, y: self.switchButton.frame.maxY, width: 100, height: 30))
        self.ActiveLabel.text = "Active"
        self.ActiveLabel.center.x = self.switchButton.center.x
        self.ActiveLabel.textColor = UIColor(hexString: self.CardDataDetails.cardnumberColor)
        self.ActiveLabel.textAlignment = .center
        self.ActiveLabel.font = UIFont.systemFont(ofSize: 13.0, weight: .thin)
        self.view.addSubview(self.ActiveLabel)
        setupEditButtonView()
    }
    
    func setupInActiveView(color:UIColor) {
        self.InActiveView = UIView(frame: self.cardView.frame)
        self.InActiveView.layer.cornerRadius = 12
        self.InActiveView.layer.masksToBounds = true
        self.InActiveView.backgroundColor = color.withAlphaComponent(0.3)
        self.InActiveView.layer.shadowColor = UIColor.lightGray.cgColor
        self.InActiveView.layer.shadowOpacity = 1
        self.InActiveView.layer.shadowOffset = CGSize(width: 0.5, height: 0.4)
        self.InActiveView.layer.shadowRadius = 6.0
        self.InActiveView.layer.masksToBounds = false
        self.view.addSubview(self.InActiveView)
        
    }
    
    func setupEditButtonView() {
        self.UnderLineView = UIView(frame: CGRect(x: 0, y: self.view.bounds.maxY-100, width: 170, height: 60))
        self.UnderLineView.backgroundColor = UIColor(hexString: self.CardDataDetails.shadowcolor)
        self.UnderLineView.layer.cornerRadius = 8
        self.UnderLineView.center.x = self.view.center.x
        self.view.addSubview(self.UnderLineView)
        
        self.EditButton = UIButton(frame: CGRect(x: 0, y: self.UnderLineView.bounds.minY, width: 170, height: 60))
        self.EditButton.setTitle("Edit Name", for: .normal)
        self.EditButton.titleLabel?.font = UIFont.systemFont(ofSize: 18.0, weight: .bold)
        self.EditButton.setTitleColor(UIColor(hexString: "#FFFFFF"), for: .normal)
        self.UnderLineView.addSubview(self.EditButton)
        self.EditButton.addTarget(self, action: #selector(EditAction), for: .touchUpInside)
        setupCardHolderTextField()
    }
    
    func setupCardHolderTextField() {
        self.CardHolderNameField = UITextField(frame: CGRect(x: 20, y: self.cardView.frame.maxY+70, width: 0, height: 30))
        self.CardHolderNameField.borderStyle = .none
        self.CardHolderNameField.text = self.CardDataDetails.cardName
        self.CardHolderNameField.delegate = self
        self.CardHolderNameField.font = UIFont.systemFont(ofSize: 18.0, weight: .bold)
        self.view.addSubview(self.CardHolderNameField)
        
        self.CardHolderNameFieldUnderLine = UIView(frame: CGRect(x: 10, y: self.CardHolderNameField.frame.maxY, width: 0, height: 2))
        self.CardHolderNameFieldUnderLine.backgroundColor = UIColor(hexString: self.CardDataDetails.shadowcolor)
        self.view.addSubview(CardHolderNameFieldUnderLine)
    }
}

//MARK: - TextfieldDelegate Events
extension DetailsViewController: UITextFieldDelegate {
    func textFieldDidChangeSelection(_ textField: UITextField) {
        
        UIView.animate(withDuration: 0.3, animations:  {
            self.cardHolderName.text = textField.text ?? ""
        })
        if textField.text ?? "" == self.CardDataDetails.cardName {
            UIView.animate(withDuration: 0.3, delay: 0.1, animations: {
                self.EditButton.setTitle("Save", for: .normal)
            })
        } else {
            UIView.animate(withDuration: 0.3, delay: 0.1, animations: {
                self.EditButton.setTitle("Save", for: .normal)
            })
        }
        let setWidth = textField.text?.SizeOf(UIFont.systemFont(ofSize: 18.0, weight: .bold))
        if setWidth?.width ?? 0.0 <= 120 {
            UIView.animate(withDuration: 0.3, animations:{
                self.CardHolderNameFieldUnderLine.frame.size.width = 150
            })
        } else {
            UIView.animate(withDuration: 0.3, animations:{
                self.CardHolderNameFieldUnderLine.frame.size.width = (setWidth?.width ?? 0.0) + 30
            })
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // get the current text, or use an empty string if that failed
            let currentText = textField.text ?? ""

            // attempt to read the range they are trying to change, or exit if we can't
            guard let stringRange = Range(range, in: currentText) else { return false }

            // add their new text to the existing text
            let updatedText = currentText.replacingCharacters(in: stringRange, with: string)

            // make sure the result is under 16 characters
            return updatedText.count <= 24
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}

//MARK: - EditButton events
extension DetailsViewController {
    @objc func EditAction(){
        if self.BottomButtonTypeEdit == false {
            UIView.animate(withDuration: 0.3, animations: {
                self.UnderLineView.frame.size.width = 80
                self.UnderLineView.center.x = self.view.center.x + 10
                self.EditButton.frame.size.width = 80
            }) {_ in
                UIView.animate(withDuration: 0.3, animations: {
                    self.UnderLineView.frame.size.width = 140
                    self.UnderLineView.center.x = self.view.center.x
                    self.EditButton.frame.size.width = 140
                }) {_ in
                    UIView.animate(withDuration: 0.3, animations:{
                        self.EditButton.setTitle("Save", for: .normal)
                        self.BottomButtonTypeEdit = true
                    }) {_ in
                        UIView.animate(withDuration: 0.5, delay: 0.1, animations: {
                            self.limitLabel.frame.size.width = 0
                            self.withdrawalLabel.frame.size.width = 0
                        }) {_ in
                            UIView.animate(withDuration: 0.5, delay: 0.1, animations:{
                                self.CardHolderNameField.frame.size.width = 250
                                let setWidth = self.CardHolderNameField.text?.SizeOf(UIFont.systemFont(ofSize: 18.0, weight: .bold))
                                if setWidth?.width ?? 0.0 <= 120 {
                                    self.CardHolderNameFieldUnderLine.frame.size.width = 150
                                } else {
                                    self.CardHolderNameFieldUnderLine.frame.size.width = (setWidth?.width ?? 0.0) + 40
                                }
                                self.CardHolderNameField.becomeFirstResponder()
                            })
                        }
                    }
                }
            }
        } else {
            self.BottomButtonTypeEdit = false
            UIView.animate(withDuration: 0.5, animations: {
                self.UnderLineView.frame.size.width = 80
                self.CardHolderNameField.frame.size.width = 0
                self.CardHolderNameFieldUnderLine.frame.size.width = 0
                self.UnderLineView.center.x = self.view.center.x + 10
                self.EditButton.frame.size.width = 80
            }) {_ in
                UIView.animate(withDuration: 0.3, animations: {
                    self.UnderLineView.frame.size.width = 140
                    self.UnderLineView.center.x = self.view.center.x
                    self.EditButton.frame.size.width = 140
                }) {_ in
                    UIView.animate(withDuration: 0.3, animations:{
                        self.EditButton.setTitle("Edit Name", for: .normal)
                        self.BottomButtonTypeEdit = true
                    }) {_ in
                        UIView.animate(withDuration: 0.5, delay: 0.1, animations: {
                            self.limitLabel.frame.size.width = self.view.frame.width
                            self.withdrawalLabel.frame.size.width = 100
                        })
                    }
                }
            }
        }
    }
}

//MARK: - Handle Swipe animation
extension DetailsViewController{
    func addSwipe() {
        let directions: [UISwipeGestureRecognizer.Direction] = [.left, .right]
        for direction in directions {
            let gesture = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe))
            gesture.direction = direction
            self.cardView.addGestureRecognizer(gesture)
        }
    }

   @objc func handleSwipe(sender: UISwipeGestureRecognizer) {
        print(sender.direction)
       if sender.direction == .left {
           UIView.transition(with: self.cardView, duration: 2, options: .transitionFlipFromRight, animations: nil, completion: nil)
           UIView.animate(withDuration: 0.2, animations:  {
               self.cardHolderName.text = "CVV"
               self.cardExpiryLabel.text = "311"
           })
       } else if sender.direction == .right{
           UIView.transition(with: self.cardView, duration: 2, options: .transitionFlipFromLeft, animations: nil, completion: nil)
           UIView.animate(withDuration: 0.2, animations:  {
               self.cardHolderName.text = self.CardDataDetails.cardName
               self.cardExpiryLabel.text = self.CardDataDetails.cardExpire
           })
       }
    }
    
    ///Handle Card Activation
    @objc func ActiveDetactiveCard(_ sender:UISwitch) {
        if sender.isOn {
            self.ActiveLabel.text = "Active"
            UIView.animate(withDuration: 0.8, delay: 0.2, animations:{
                self.InActiveView.removeFromSuperview()
            }) {_ in
                UIView.animate(withDuration: 0.5, animations: {
                    self.cardNumber.text = self.CardDataDetails.cardNumber
                    self.cardView.isUserInteractionEnabled = true
                })
            }
        } else {
            self.ActiveLabel.text = "Inactive"
            UIView.animate(withDuration: 0.8, delay: 0.2, animations:{
                self.setupInActiveView(color: .white)
            }) {_ in
                UIView.animate(withDuration: 0.5, animations: {
                    self.cardNumber.text = "xxxx xxxx xxxx xxxx"
                    self.cardView.isUserInteractionEnabled = false
                })
            }
        }
    }
}

//MARL: - Status bar change
extension DetailsViewController {
    func SetupStatusBar(color:String) {
        if #available(iOS 13.0, *) {
            let app = UIApplication.shared
            let statusBarHeight: CGFloat = app.statusBarFrame.size.height
            
            let statusbarView = UIView()
            statusbarView.backgroundColor = UIColor(hexString: color)
            view.addSubview(statusbarView)
            
            statusbarView.translatesAutoresizingMaskIntoConstraints = false
            statusbarView.heightAnchor
                .constraint(equalToConstant: statusBarHeight).isActive = true
            statusbarView.widthAnchor
                .constraint(equalTo: view.widthAnchor, multiplier: 1.0).isActive = true
            statusbarView.topAnchor
                .constraint(equalTo: view.topAnchor).isActive = true
            statusbarView.centerXAnchor
                .constraint(equalTo: view.centerXAnchor).isActive = true
            
        } else {
            let statusBar = UIApplication.shared.value(forKeyPath: "statusBarWindow.statusBar") as? UIView
            statusBar?.backgroundColor = UIColor.red
        }
    }
}
