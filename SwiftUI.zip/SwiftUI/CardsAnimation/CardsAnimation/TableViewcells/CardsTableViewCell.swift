//
//  CardsTableViewCell.swift
//  CardsAnimation
//
//  Created by Mihir vyas on 08/07/23.
//

import UIKit

class CardsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var mainV: UIView!
    @IBOutlet weak var bottomV: UIView!
    @IBOutlet weak var cardnumberLbl: UILabel!
    @IBOutlet weak var cardtypeImage: UIImageView!
    @IBOutlet weak var cardHolderNumber: UILabel!
    @IBOutlet weak var cardHolderExpiry: UILabel!
    @IBOutlet weak var cardCompanyLogo: UIButton!
    
    @IBOutlet weak var mainV2: UIView!
    @IBOutlet weak var bottomV2: UIView!
    @IBOutlet weak var cardnumberLbl2: UILabel!
    @IBOutlet weak var cardtypeImage2: UIImageView!
    @IBOutlet weak var cardHolderNumber2: UILabel!
    @IBOutlet weak var cardHolderExpiry2: UILabel!
    @IBOutlet weak var cardCompanyLogo2: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setupDetails(data:CardModel) {
        if data.isCardHide {
            self.mainV.isHidden = false
            self.mainV2.isHidden = true
            self.selectionStyle = .none
            self.bottomV.backgroundColor = UIColor(hexString: data.cardbottomColor)
            self.cardnumberLbl.text = data.cardNumber
            self.cardHolderNumber.text = data.cardName
            self.cardHolderExpiry.text = data.cardExpire
            self.mainV.backgroundColor = UIColor(hexString: data.cardBackgroundColor)
            self.cardtypeImage.image = data.cardtypeImage
            self.cardnumberLbl.textColor = UIColor(hexString: data.cardnumberColor)
            self.cardHolderNumber.textColor = UIColor(hexString: data.cardNameColor)
            self.cardHolderExpiry.textColor = UIColor(hexString: data.cardNameColor)
            self.cardnumberLbl.font = UIFont.systemFont(ofSize: 17.0, weight: .bold)
            self.cardHolderExpiry.font = UIFont.systemFont(ofSize: 16.0, weight: .medium)
            self.cardHolderNumber.font = UIFont.systemFont(ofSize: 17.0, weight: .bold)
            self.bottomV.layer.cornerRadius = 10
            self.bottomV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            self.cardCompanyLogo.setImage(UIImage(named: "inifnity")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate), for: .normal)
            self.cardCompanyLogo.tintColor = UIColor(hexString: data.CompanyImagecolor)
            
        }
    }
}
