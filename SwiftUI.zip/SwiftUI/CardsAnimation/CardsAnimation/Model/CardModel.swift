//
//  CardModel.swift
//  CardsAnimation
//
//  Created by Mihir vyas on 09/07/23.
//

import UIKit

struct CardModel {
    var cardImage = UIImage()
    var cardName = String()
    var cardNumber = String()
    var cardExpire = String()
    var cardtypeImage = UIImage()
    var cardType = String()
    var cardbottomColor = String()
    var cardBackgroundColor = String()
    var cardnumberColor = String()
    var cardNameColor = String()
    var isCardHide = Bool()
    var isFlip = Bool()
    var shadowcolor = String()
    var withdrawal = String()
    var CompanyImagecolor = String()
}
