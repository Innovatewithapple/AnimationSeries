//
//  ViewController.swift
//  CardsAnimation
//
//  Created by Mihir vyas on 08/07/23.
//

import UIKit
var CardData = [CardModel]()
class ViewController: UIViewController {
    
   
    
    ///Explore Button
    var ExploreButton: UIButton!
    
    ///Underline
    var UnderlineView: UIView!
    
    ///Cardview
    var cardView: UIView!
    var bottomView: UIView!
    
    ///Tableview
    var tableV: UITableView!
    var tableVCellHeight = 220
    
    var savedFlip = true
    var isanimate = false
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.Setupview()
    }

    func Setupview() {
        self.view.backgroundColor = UIColor(hexString: "18122B")//Background color
        self.SetupTableView()
    }
    
    func SetupBottomButton() {
        self.ExploreButton = UIButton(frame: CGRect(x: 0, y: self.view.frame.maxY-120, width: self.view.frame.width-80, height: 40))
        self.ExploreButton.center.x = self.view.center.x
        self.ExploreButton.setTitle("Explore", for: .normal)
        self.ExploreButton.setTitleColor(UIColor.white, for: .normal)
        self.ExploreButton.titleLabel?.font = UIFont.systemFont(ofSize: 18.0, weight: .bold)
        self.view.addSubview(self.ExploreButton)
        self.CreateUnderLine()
    }
    
    func CreateUnderLine() {
        self.UnderlineView = UIView(frame: CGRect(x: 0, y: self.ExploreButton.frame.maxY-3, width: 80, height: 2))
        self.UnderlineView.center.x = self.view.center.x
        self.UnderlineView.backgroundColor = UIColor.white
        self.view.addSubview(self.UnderlineView)
       // self.CreateCardViews()
    }
    
    func SetupTableView(){
        self.tableV = UITableView(frame: CGRect(x: 10, y: self.view.frame.minY+50, width: self.view.frame.width-10, height: self.view.frame.height-10))
        self.tableV.separatorStyle = .none
        self.tableV.center = self.view.center
        self.tableV.delegate = self
        self.tableV.dataSource = self
        self.tableV.backgroundColor = UIColor.clear
        self.tableV.register(UINib(nibName: "CardsTableViewCell", bundle: nil), forCellReuseIdentifier: "CardsTableViewCell")
        self.view.addSubview(self.tableV)
        self.setupData()
    }
    
    func setupCardView() {
        self.cardView = UIView(frame: CGRect(x: 0, y: 50, width: Int(self.view.frame.width)-30, height: 230))
        self.cardView.center.x = self.view.center.x
        self.cardView.layer.cornerRadius = 12
        self.cardView.layer.masksToBounds = true;
        self.cardView.backgroundColor = UIColor(hexString: "#C0D9F0")
        self.cardView.layer.shadowColor = UIColor(hexString: "#52A8E1").cgColor
        self.cardView.layer.shadowOpacity = 1
        self.cardView.layer.shadowOffset = CGSize(width: 0.5, height: 0.4)
        self.cardView.layer.shadowRadius = 6.0
        self.cardView.layer.masksToBounds = false
        self.view.addSubview(self.cardView)
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CardData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(self.tableVCellHeight)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableV.dequeueReusableCell(withIdentifier: "CardsTableViewCell", for: indexPath) as! CardsTableViewCell
        cell.backgroundColor = UIColor.clear
        cell.contentView.backgroundColor = UIColor.clear
        cell.mainV.layer.cornerRadius = 10
        cell.mainV2.layer.cornerRadius = 10
        cell.setupDetails(data: CardData[indexPath.row])
        if self.savedFlip {
            cell.transform = CGAffineTransform(translationX: cell.contentView.frame.width, y: 0)
            UIView.animate(withDuration: 3, delay: 0.06*Double(indexPath.row), usingSpringWithDamping: 0.5, initialSpringVelocity: 0.2, options: .curveEaseIn, animations: {
                cell.transform = CGAffineTransform(translationX: cell.contentView.frame.width, y: cell.contentView.frame.height)
            })
        }
            if self.isanimate {
                self.isanimate = false
                UIView.animate(withDuration: 0.9, delay: 0.2) {
                    cell.mainV.layer.shadowColor = UIColor(hexString: "#52A8E1").cgColor
                    cell.mainV.layer.shadowOpacity = 1
                    cell.mainV.layer.shadowOffset = CGSize(width: 0.5, height: 0.4)
                    cell.mainV.layer.shadowRadius = 6.0
                    cell.mainV.layer.masksToBounds = false
                    self.view.backgroundColor = UIColor(hexString: "#AFD6EF")
                }
            }
            return cell
    }
}

//MARK: - Card Model Manage
extension ViewController{
    func setupData() {
        CardData.append(CardModel(cardImage: UIImage(named: "lines")!, cardName: "Peter Chain", cardNumber: "xxxx xxxx xxxx 3412", cardExpire: "09/24", cardtypeImage: UIImage(named: "visa")!, cardType: "visa", cardbottomColor: "FFF6F4", cardBackgroundColor: "#C0D9F0", cardnumberColor: "2B2730", cardNameColor: "#2B2730",isCardHide: true, shadowcolor: "#52A8E1", withdrawal: "$ 10,000 OF $ 45,000", CompanyImagecolor: "#000000"))
        CardData.append(CardModel(cardImage: UIImage(named: "graph")!, cardName: "Mellisa June", cardNumber: "xxxx xxxx xxxx 2034", cardExpire: "03/25", cardtypeImage: UIImage(named: "rupay")!, cardType: "rupay", cardbottomColor: "#B31312", cardBackgroundColor: "#EEE2DE", cardnumberColor: "2B2730", cardNameColor: "#FFFFFF",isCardHide: true, shadowcolor: "#2B2A4C", withdrawal: "$ 50,000 OF $ 100,000", CompanyImagecolor: "#000000"))
        CardData.append(CardModel(cardImage: UIImage(named: "earth")!, cardName: "Harvey Spector", cardNumber: "xxxx xxxx xxxx 0078", cardExpire: "12/23", cardtypeImage: UIImage(named: "master")!, cardType: "master", cardbottomColor: "#F9DBBB", cardBackgroundColor: "#609EA2", cardnumberColor: "#F5F5F5", cardNameColor: "#20262E",isCardHide: true, shadowcolor: "#245953", withdrawal: "$ 400 OF $ 10,000", CompanyImagecolor: "#FFFFFF"))
        CardData.append(CardModel(cardImage: UIImage(named: "graph")!, cardName: "Thomas Jr.", cardNumber: "xxxx xxxx xxxx 0098", cardExpire: "02/25", cardtypeImage: UIImage(named: "visa")!, cardType: "visa", cardbottomColor: "#2A2F4F", cardBackgroundColor: "#917FB3", cardnumberColor: "#FFFFFF", cardNameColor: "#FFFFFF",isCardHide: true, shadowcolor: "#E5BEEC", withdrawal: "$ 20,000 OF $ 100,000", CompanyImagecolor: "#FFFFFF"))
        CardData.append(CardModel(cardImage: UIImage(named: "graph")!, cardName: "Serena W", cardNumber: "xxxx xxxx xxxx 8762", cardExpire: "06/25", cardtypeImage: UIImage(named: "visa")!, cardType: "visa", cardbottomColor: "#AEC2B6", cardBackgroundColor: "#BBD6B8", cardnumberColor: "#000000", cardNameColor: "#000000",isCardHide: true, shadowcolor: "#94AF9F", withdrawal: "$ 200,000 OF $ 500,000", CompanyImagecolor: "#000000"))
        self.tableV.reloadData()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        vc.CardDataDetails = CardData[indexPath.row]
        vc.index = indexPath.row
        vc.statusBarColor = CardData[indexPath.row].shadowcolor
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true)
    }
}
